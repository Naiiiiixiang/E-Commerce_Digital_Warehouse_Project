package com.atguigu;

import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.exec.UDFArgumentLengthException;
import org.apache.hadoop.hive.ql.exec.UDFArgumentTypeException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDTF;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.json.JSONArray;

import java.util.Collections;
import java.util.List;


public class ExplodeJsonArray extends GenericUDTF {

    @Override
    public StructObjectInspector initialize(ObjectInspector[] argOIs) throws UDFArgumentException {
        if (argOIs.length != 1)
            throw new UDFArgumentLengthException("参数个数只能有一个");
        if (!"string".equals(argOIs[0].getTypeName()))
            throw new UDFArgumentTypeException(0, "必须是string类型");

        List<String> names = Collections.singletonList("result");
        List<ObjectInspector> inspectors = Collections.singletonList(PrimitiveObjectInspectorFactory.javaStringObjectInspector);
        return ObjectInspectorFactory.getStandardStructObjectInspector(names, inspectors);
    }

    @Override
    public void process(Object[] objects) throws HiveException {
        //1. 生成JsonArray
        String line = objects[0].toString();
        JSONArray jsonArray = new JSONArray(line);

        //2. 挨个forward出去
        for (int i = 0; i < jsonArray.length(); i++) {
            String[] result = new String[1];
            result[0] = jsonArray.getString(i);
            forward(result);
        }
    }

    @Override
    public void close() throws HiveException {

    }
}
